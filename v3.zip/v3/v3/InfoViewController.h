//
//  InfoViewController.h
//  v2
//
//  Created by John Bogil on 10/11/15.
//  Copyright © 2015 John Bogil. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoViewController : UIViewController
@end
