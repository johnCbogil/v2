//
//  UIColor+voicesOrange.m
//  v2
//
//  Created by John Bogil on 11/1/15.
//  Copyright © 2015 John Bogil. All rights reserved.
//

#import "UIColor+voicesOrange.h"

@implementation UIColor (voicesOrange)
// GET THE CORRECT RGB VALUE FOR THE VOICES ORANGE
+ (UIColor*)voicesOrange {
    return [UIColor orangeColor];
}
@end
