//
//  OnboardingViewController.h
//  v3
//
//  Created by John Bogil on 1/1/16.
//  Copyright © 2016 John Bogil. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OnboardingViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIPageControl *pageControl;

@end
