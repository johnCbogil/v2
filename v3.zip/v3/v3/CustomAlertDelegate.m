//
//  CustomAlertDelegate.m
//  v2
//
//  Created by John Bogil on 11/14/15.
//  Copyright © 2015 John Bogil. All rights reserved.
//

#import "CustomAlertDelegate.h"

@implementation CustomAlertDelegate

@end
