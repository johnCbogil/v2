//
//  Onboarding2ViewController.h
//  v3
//
//  Created by John Bogil on 1/1/16.
//  Copyright © 2016 John Bogil. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LocationService.h"

@interface Onboarding2ViewController : UIViewController <CLLocationManagerDelegate>

@end
